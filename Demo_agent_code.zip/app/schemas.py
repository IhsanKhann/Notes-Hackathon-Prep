"""
CargoSense — Pydantic Schemas (Integration Contract)
These models define the exact request/response shapes between
the FastAPI backend and the Streamlit frontend.
"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, Any


# ─── Request ────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str = Field(
        ...,
        description="The user's natural language shipment query",
        example="Electronics from Shenzhen via Hormuz to Karachi — what is my risk today?"
    )


# ─── Sub-Models ─────────────────────────────────────────────────────────────

class DutyBreakdown(BaseModel):
    hs_code: Optional[str] = Field(None, description="HS code used for calculation")
    value_usd: Optional[float] = Field(None, description="Declared value in USD")
    value_pkr: Optional[float] = Field(None, description="Value converted to PKR")
    customs_duty_pct: float = Field(0.0, description="Customs duty rate (0–1)")
    customs_duty_pkr: float = Field(0.0, description="Customs duty amount in PKR")
    sales_tax_pct: float = Field(0.0, description="Sales tax rate (0–1)")
    sales_tax_pkr: float = Field(0.0, description="Sales tax amount in PKR")
    withholding_tax_pct: float = Field(0.0, description="WHT rate (0–1)")
    withholding_tax_pkr: float = Field(0.0, description="WHT amount in PKR")
    additional_customs_duty_pct: float = Field(0.0)
    additional_customs_duty_pkr: float = Field(0.0)
    regulatory_duty_pct: float = Field(0.0)
    regulatory_duty_pkr: float = Field(0.0)
    total_duty_pkr: float = Field(0.0, description="Grand total of all duties in PKR")
    effective_duty_rate: float = Field(0.0, description="Total duties as % of value")
    usd_to_pkr_rate: float = Field(278.5, description="Exchange rate used")
    notes: Optional[str] = None


class RouteInfo(BaseModel):
    origin: Optional[str] = None
    destination: Optional[str] = None
    recommended_route: Optional[str] = None
    risk_color: str = Field("GREEN", description="RED / AMBER / GREEN")
    transit_days: Optional[int] = None
    cost_multiplier: Optional[float] = None
    insurance_surcharge_pct: Optional[float] = None
    active_threats: list[str] = Field(default_factory=list)
    alternative_routes: list[str] = Field(default_factory=list)


# ─── Main Response ───────────────────────────────────────────────────────────

class ChatResponse(BaseModel):
    """
    The integration contract between FastAPI and Streamlit.
    Tahreem's UI reads every field here to build the dashboard.
    """
    # Core risk signal
    risk_level: str = Field(
        ...,
        description="HIGH / MEDIUM / LOW",
        example="HIGH"
    )
    risk_score: float = Field(
        ...,
        description="Numeric risk score from 0 (safe) to 10 (extreme)",
        example=8.2
    )

    # News intelligence
    news_summary: str = Field(
        ...,
        description="1–3 sentence summary of relevant geopolitical/maritime news",
        example="Houthi forces attacked two vessels in the Red Sea this week..."
    )

    # Financial intelligence
    duty_breakdown: Optional[DutyBreakdown] = Field(
        None,
        description="Full PKR duty calculation if an HS code was identified"
    )

    # Route recommendation
    route_recommendation: str = Field(
        ...,
        description="Suggested alternative route or confirmation of current route",
        example="Reroute via Colombo to avoid Hormuz. Adds 6 days but saves 32% on insurance."
    )

    # Route details for heat map
    route_info: Optional[RouteInfo] = None

    # Full agent answer
    agent_response: str = Field(
        ...,
        description="Complete natural language answer from the Gemini agent"
    )

    # Metadata
    tools_used: list[str] = Field(
        default_factory=list,
        description="Which function-calling tools were invoked"
    )
    model_used: str = Field("gemini-2.0-flash", description="Gemini model version")


# ─── Health ─────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = "1.0.0"
    agent: str = "CargoSense Shipment Intelligence Agent"