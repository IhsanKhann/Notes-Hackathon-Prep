"""
CargoSense — Streamlit Frontend
Dark-mode professional dashboard for the Shipment Intelligence Agent.
Connects to the FastAPI /chat endpoint and renders:
  • Chat interface (sidebar)
  • Route risk heat map (Folium)
  • Structured report card (Streamlit columns + metrics)
"""

import json
import time
import math
import pathlib
import requests
import streamlit as st
import folium
from streamlit_folium import st_folium

# ─── Config ──────────────────────────────────────────────────────────────────

API_BASE = "http://localhost:8000"
DEMO_SCENARIOS_FILE = pathlib.Path(__file__).parent.parent / "data" / "demo_scenarios.json"
ROUTE_DATA_FILE = pathlib.Path(__file__).parent.parent / "data" / "route_risk.json"

DEFAULT_QUERY = "Electronics from Shenzhen via Hormuz to Karachi — what is my risk today?"

# ─── Page Setup ──────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="CargoSense — Shipment Intelligence",
    page_icon="🚢",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Dark-Mode CSS ────────────────────────────────────────────────────────────

st.markdown("""
<style>
  /* ── Base dark theme ── */
  .stApp { background-color: #0d1117; color: #e6edf3; }
  .main .block-container { padding-top: 1.5rem; padding-bottom: 2rem; }

  /* ── Sidebar ── */
  [data-testid="stSidebar"] {
    background: linear-gradient(180deg, #161b22 0%, #0d1117 100%);
    border-right: 1px solid #21262d;
  }
  [data-testid="stSidebar"] .stMarkdown p { color: #8b949e; font-size: 0.82rem; }

  /* ── Logo / Brand ── */
  .brand-header {
    background: linear-gradient(135deg, #1a2742 0%, #0d1f3c 100%);
    border: 1px solid #1f6feb;
    border-radius: 12px;
    padding: 1.2rem 1.5rem;
    margin-bottom: 1.5rem;
    text-align: center;
  }
  .brand-header h1 { color: #58a6ff; font-size: 1.9rem; margin: 0; letter-spacing: -0.5px; }
  .brand-header p  { color: #8b949e; font-size: 0.78rem; margin: 4px 0 0 0; }

  /* ── Chat messages ── */
  .chat-user {
    background: #1a2742; border: 1px solid #1f6feb; border-radius: 10px;
    padding: 0.85rem 1rem; margin: 0.5rem 0; color: #cdd9e5;
  }
  .chat-agent {
    background: #161b22; border: 1px solid #21262d; border-radius: 10px;
    padding: 0.85rem 1rem; margin: 0.5rem 0; color: #e6edf3;
  }
  .chat-label { font-size: 0.7rem; color: #6e7681; text-transform: uppercase;
                letter-spacing: 0.08em; margin-bottom: 4px; }

  /* ── Risk badges ── */
  .risk-high   { background:#3d1515; border:1px solid #f85149; color:#f85149;
                 border-radius:6px; padding:2px 10px; font-weight:700; font-size:0.85rem; }
  .risk-medium { background:#2d2208; border:1px solid #e3b341; color:#e3b341;
                 border-radius:6px; padding:2px 10px; font-weight:700; font-size:0.85rem; }
  .risk-low    { background:#0f2d1a; border:1px solid #3fb950; color:#3fb950;
                 border-radius:6px; padding:2px 10px; font-weight:700; font-size:0.85rem; }

  /* ── Report card sections ── */
  .report-section {
    background: #161b22; border: 1px solid #21262d; border-radius: 10px;
    padding: 1rem 1.2rem; margin-bottom: 1rem;
  }
  .report-section h4 { color: #58a6ff; margin: 0 0 0.7rem 0; font-size: 0.9rem;
                       text-transform: uppercase; letter-spacing: 0.06em; }

  /* ── Metrics override ── */
  [data-testid="metric-container"] {
    background: #1c2128; border: 1px solid #30363d; border-radius: 8px; padding: 0.7rem;
  }
  [data-testid="metric-container"] label { color: #8b949e !important; font-size: 0.75rem !important; }
  [data-testid="metric-container"] [data-testid="stMetricValue"] {
    color: #e6edf3 !important; font-size: 1.5rem !important;
  }

  /* ── Section headers ── */
  .section-title {
    color: #58a6ff; font-size: 1rem; font-weight: 600;
    border-bottom: 1px solid #21262d; padding-bottom: 6px; margin-bottom: 1rem;
    text-transform: uppercase; letter-spacing: 0.08em;
  }

  /* ── Threat pills ── */
  .threat-pill {
    display: inline-block; background: #2d1a1a; border: 1px solid #f85149;
    color: #f85149; border-radius: 20px; padding: 2px 10px;
    font-size: 0.75rem; margin: 2px;
  }

  /* ── Demo scenario buttons ── */
  div[data-testid="stButton"] > button {
    background: #1c2128; border: 1px solid #30363d; color: #cdd9e5;
    border-radius: 8px; width: 100%; text-align: left; font-size: 0.82rem;
    padding: 0.5rem 0.8rem; transition: all 0.2s;
  }
  div[data-testid="stButton"] > button:hover {
    border-color: #1f6feb; background: #1a2742; color: #58a6ff;
  }

  /* ── Input area ── */
  .stTextArea textarea {
    background: #1c2128 !important; border: 1px solid #30363d !important;
    color: #e6edf3 !important; border-radius: 8px !important;
  }
  .stTextArea textarea:focus {
    border-color: #1f6feb !important; box-shadow: 0 0 0 2px rgba(31,111,235,0.2) !important;
  }

  /* ── Primary button ── */
  .stButton [kind="primary"] button,
  button[data-testid="baseButton-primary"] {
    background: linear-gradient(135deg, #1f6feb, #388bfd) !important;
    border: none !important; color: white !important;
    border-radius: 8px !important; font-weight: 600 !important;
  }

  /* ── Folium map container ── */
  iframe { border-radius: 10px; border: 1px solid #21262d !important; }

  /* ── Scrollable chat history ── */
  .chat-history {
    max-height: 380px; overflow-y: auto;
    border: 1px solid #21262d; border-radius: 10px; padding: 0.8rem;
    background: #0d1117; margin-bottom: 1rem;
  }
</style>
""", unsafe_allow_html=True)


# ─── Helpers ─────────────────────────────────────────────────────────────────

@st.cache_data
def load_demo_scenarios():
    try:
        with open(DEMO_SCENARIOS_FILE) as f:
            return json.load(f)
    except Exception:
        return []


@st.cache_data
def load_route_data():
    try:
        with open(ROUTE_DATA_FILE) as f:
            return json.load(f)
    except Exception:
        return {"routes": {}, "ports": {}}


def call_api(message: str) -> dict | None:
    try:
        resp = requests.post(
            f"{API_BASE}/chat",
            json={"message": message},
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()
    except requests.exceptions.ConnectionError:
        st.error(
            "⚠️ Cannot connect to CargoSense API. "
            "Start the backend: `uvicorn app.main:app --reload`"
        )
        return None
    except requests.exceptions.HTTPError as e:
        st.error(f"API error {e.response.status_code}: {e.response.text[:200]}")
        return None
    except Exception as e:
        st.error(f"Unexpected error: {e}")
        return None


def risk_badge(level: str) -> str:
    cls = {"HIGH": "risk-high", "MEDIUM": "risk-medium", "LOW": "risk-low"}.get(level, "risk-low")
    emoji = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}.get(level, "⚪")
    return f'<span class="{cls}">{emoji} {level}</span>'


def score_to_color(score: float) -> str:
    if score >= 7:
        return "#f85149"
    elif score >= 4:
        return "#e3b341"
    return "#3fb950"


def format_pkr(value: float) -> str:
    if value >= 1_000_000:
        return f"₨ {value/1_000_000:.2f}M"
    elif value >= 1_000:
        return f"₨ {value/1_000:.1f}K"
    return f"₨ {value:.0f}"


# ─── Heat Map Builder ─────────────────────────────────────────────────────────

def build_heatmap(route_data: dict | None = None) -> folium.Map:
    """Build a Folium world map with maritime route overlays."""
    static = load_route_data()
    ports = static.get("ports", {})

    m = folium.Map(
        location=[20, 70],
        zoom_start=4,
        tiles="CartoDB dark_matter",
        prefer_canvas=True,
    )

    # ── Port markers ─────────────────────────────────────────────────────────
    PORT_STYLES = {
        "shenzhen":  {"color": "#58a6ff", "icon": "anchor",   "prefix": "fa"},
        "hormuz":    {"color": "#f85149", "icon": "warning",  "prefix": "fa"},
        "karachi":   {"color": "#3fb950", "icon": "ship",     "prefix": "fa"},
        "colombo":   {"color": "#3fb950", "icon": "anchor",   "prefix": "fa"},
        "dubai":     {"color": "#e3b341", "icon": "anchor",   "prefix": "fa"},
        "suez":      {"color": "#e3b341", "icon": "warning",  "prefix": "fa"},
        "rotterdam": {"color": "#58a6ff", "icon": "anchor",   "prefix": "fa"},
        "aden":      {"color": "#f85149", "icon": "exclamation-triangle", "prefix": "fa"},
    }

    for key, port in ports.items():
        style = PORT_STYLES.get(key, {"color": "#8b949e", "icon": "circle", "prefix": "fa"})
        icon_color = "red" if style["color"] == "#f85149" else (
            "green" if style["color"] == "#3fb950" else (
                "orange" if style["color"] == "#e3b341" else "blue"
            )
        )
        folium.Marker(
            location=[port["lat"], port["lon"]],
            tooltip=f"<b>{port['label']}</b>",
            popup=folium.Popup(port["label"], max_width=150),
            icon=folium.Icon(
                color=icon_color,
                icon=style["icon"],
                prefix=style["prefix"],
            ),
        ).add_to(m)

    # ── Route lines ───────────────────────────────────────────────────────────
    ROUTE_LINES = [
        {
            "coords": [
                [ports["shenzhen"]["lat"], ports["shenzhen"]["lon"]],
                [ports["hormuz"]["lat"],   ports["hormuz"]["lon"]],
                [ports["karachi"]["lat"],  ports["karachi"]["lon"]],
            ],
            "color": "#f85149",
            "weight": 3,
            "label": "Shenzhen → Hormuz → Karachi (HIGH RISK)",
            "dash_array": "6 4",
        },
        {
            "coords": [
                [ports["shenzhen"]["lat"], ports["shenzhen"]["lon"]],
                [ports["colombo"]["lat"],  ports["colombo"]["lon"]],
                [ports["karachi"]["lat"],  ports["karachi"]["lon"]],
            ],
            "color": "#3fb950",
            "weight": 2.5,
            "label": "Shenzhen → Colombo → Karachi (LOW RISK ✓)",
            "dash_array": None,
        },
        {
            "coords": [
                [ports["shenzhen"]["lat"], ports["shenzhen"]["lon"]],
                [ports["suez"]["lat"],     ports["suez"]["lon"]],
                [ports["karachi"]["lat"],  ports["karachi"]["lon"]],
            ],
            "color": "#e3b341",
            "weight": 2,
            "label": "Shenzhen → Suez → Karachi (MEDIUM RISK)",
            "dash_array": "4 4",
        },
        {
            "coords": [
                [ports["dubai"]["lat"],   ports["dubai"]["lon"]],
                [ports["karachi"]["lat"], ports["karachi"]["lon"]],
            ],
            "color": "#3fb950",
            "weight": 2,
            "label": "Dubai → Karachi (LOW RISK)",
            "dash_array": None,
        },
    ]

    for route in ROUTE_LINES:
        folium.PolyLine(
            locations=route["coords"],
            color=route["color"],
            weight=route["weight"],
            opacity=0.85,
            dash_array=route.get("dash_array"),
            tooltip=route["label"],
        ).add_to(m)

    # ── Danger zone circle (Gulf of Aden) ─────────────────────────────────────
    folium.Circle(
        location=[ports["aden"]["lat"], ports["aden"]["lon"]],
        radius=220_000,
        color="#f85149",
        fill=True,
        fill_color="#f85149",
        fill_opacity=0.08,
        tooltip="⚠️ Active Conflict Zone — Houthi Operations",
    ).add_to(m)

    # ── Hormuz risk circle ────────────────────────────────────────────────────
    folium.Circle(
        location=[ports["hormuz"]["lat"], ports["hormuz"]["lon"]],
        radius=180_000,
        color="#f85149",
        fill=True,
        fill_color="#f85149",
        fill_opacity=0.10,
        tooltip="⚠️ Iranian Naval Activity — UKMTO Advisory Active",
    ).add_to(m)

    # ── Legend ────────────────────────────────────────────────────────────────
    legend_html = """
    <div style="position:fixed;bottom:20px;left:20px;background:#161b22;
                border:1px solid #30363d;border-radius:10px;padding:12px 16px;
                z-index:9999;font-size:12px;color:#e6edf3;line-height:1.8;">
      <b style="color:#58a6ff;">RISK LEGEND</b><br>
      <span style="color:#f85149;">━━</span> High Risk Route<br>
      <span style="color:#e3b341;">━━</span> Medium Risk Route<br>
      <span style="color:#3fb950;">━━</span> Low Risk Route<br>
      <span style="color:#f85149;">●</span> Active Conflict Zone
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))

    return m


# ─── Report Card ─────────────────────────────────────────────────────────────

def render_report_card(data: dict):
    """Renders the structured risk report card from the API response."""
    risk_level = data.get("risk_level", "UNKNOWN")
    risk_score  = data.get("risk_score", 0.0)
    duty        = data.get("duty_breakdown")
    route_info  = data.get("route_info")
    tools_used  = data.get("tools_used", [])

    st.markdown('<div class="section-title">📊 INTELLIGENCE REPORT</div>', unsafe_allow_html=True)

    # ── Row 1: Core risk metrics ──────────────────────────────────────────────
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Risk Level", risk_level, help="Agent-assessed risk level")
    with c2:
        color = score_to_color(risk_score)
        st.metric("Risk Score", f"{risk_score:.1f} / 10")
    with c3:
        if route_info:
            st.metric("Transit Days", f"{route_info.get('transit_days', '—')} days")
        else:
            st.metric("Transit Days", "—")
    with c4:
        if route_info:
            multiplier = route_info.get("cost_multiplier", 1.0)
            delta_pct  = (multiplier - 1.0) * 100
            st.metric("Cost Multiplier", f"{multiplier:.2f}×",
                      delta=f"+{delta_pct:.0f}% vs baseline",
                      delta_color="inverse")
        else:
            st.metric("Cost Multiplier", "—")

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Row 2: Duty breakdown + Route info ────────────────────────────────────
    left_col, right_col = st.columns([1, 1])

    with left_col:
        st.markdown('<div class="report-section">', unsafe_allow_html=True)
        st.markdown("<h4>💰 DUTY BREAKDOWN (PKR)</h4>", unsafe_allow_html=True)
        if duty:
            dc1, dc2 = st.columns(2)
            with dc1:
                st.metric("Customs Duty",
                          format_pkr(duty.get("customs_duty_pkr", 0)),
                          help=f"{duty.get('customs_duty_pct', 0)*100:.0f}% of CIF value")
                st.metric("Sales Tax (GST)",
                          format_pkr(duty.get("sales_tax_pkr", 0)),
                          help=f"{duty.get('sales_tax_pct', 0)*100:.0f}%")
                st.metric("Regulatory Duty",
                          format_pkr(duty.get("regulatory_duty_pkr", 0)),
                          help=f"{duty.get('regulatory_duty_pct', 0)*100:.0f}%")
            with dc2:
                st.metric("WHT",
                          format_pkr(duty.get("withholding_tax_pkr", 0)),
                          help=f"{duty.get('withholding_tax_pct', 0)*100:.0f}%")
                st.metric("ACD",
                          format_pkr(duty.get("additional_customs_duty_pkr", 0)),
                          help=f"{duty.get('additional_customs_duty_pct', 0)*100:.0f}%")
                st.metric("Effective Rate",
                          f"{duty.get('effective_duty_rate', 0):.1f}%")

            st.divider()
            total = duty.get("total_duty_pkr", 0)
            landed = duty.get("total_landed_cost_pkr", 0)
            t1, t2 = st.columns(2)
            with t1:
                st.metric("**Total Duties**", format_pkr(total))
            with t2:
                st.metric("**Landed Cost**", format_pkr(landed))

            rate = duty.get("usd_to_pkr_rate", 278.5)
            hs   = duty.get("hs_code", "—")
            st.caption(f"HS Code: {hs} | USD/PKR: {rate} | {duty.get('notes', '')}")
        else:
            st.info("No HS code detected in your query. Mention an HS code or product type for duty calculation.")
        st.markdown("</div>", unsafe_allow_html=True)

    with right_col:
        st.markdown('<div class="report-section">', unsafe_allow_html=True)
        st.markdown("<h4>🗺️ ROUTE INTELLIGENCE</h4>", unsafe_allow_html=True)
        if route_info:
            risk_color = route_info.get("risk_color", "GREEN")
            badge_class = {
                "RED": "risk-high", "AMBER": "risk-medium", "GREEN": "risk-low"
            }.get(risk_color, "risk-low")
            emoji_map = {"RED": "🔴", "AMBER": "🟡", "GREEN": "🟢"}
            st.markdown(
                f'<span class="{badge_class}">{emoji_map.get(risk_color, "⚪")} {risk_color} CORRIDOR</span>',
                unsafe_allow_html=True
            )
            st.markdown("<br>", unsafe_allow_html=True)

            rc1, rc2 = st.columns(2)
            with rc1:
                ins_pct = (route_info.get("insurance_surcharge_pct", 0) or 0) * 100
                st.metric("Insurance Surcharge", f"+{ins_pct:.0f}%")
            with rc2:
                cost_m  = route_info.get("cost_multiplier", 1.0) or 1.0
                st.metric("Freight Multiplier", f"{cost_m:.2f}×")

            threats = route_info.get("active_threats", [])
            if threats:
                st.markdown("**Active Threats:**")
                pills = " ".join(f'<span class="threat-pill">⚠ {t}</span>' for t in threats[:4])
                st.markdown(pills, unsafe_allow_html=True)

            st.markdown("<br>**Recommended Route:**", unsafe_allow_html=True)
            rec = route_info.get("recommended_route", "—")
            st.markdown(f"> ✅ `{rec}`")

            alts = route_info.get("alternative_routes", [])
            if alts:
                st.markdown("**Alternatives:**")
                for alt in alts[:2]:
                    st.markdown(f"- {alt}")
        else:
            st.info("Mention a route (e.g., 'Shenzhen to Karachi via Hormuz') for route intelligence.")
        st.markdown("</div>", unsafe_allow_html=True)

    # ── Route recommendation banner ───────────────────────────────────────────
    rec_text = data.get("route_recommendation", "")
    if rec_text:
        st.markdown('<div class="report-section">', unsafe_allow_html=True)
        st.markdown("<h4>🧭 AGENT RECOMMENDATION</h4>", unsafe_allow_html=True)
        st.markdown(f"_{rec_text}_")
        st.markdown("</div>", unsafe_allow_html=True)

    # ── Tools used ────────────────────────────────────────────────────────────
    if tools_used:
        tool_icons = {
            "get_news": "📰 News Feed",
            "calculate_duty": "💰 Duty Calculator",
            "get_route_risk": "🗺️ Route Risk Engine",
        }
        tool_labels = [tool_icons.get(t, t) for t in tools_used]
        st.caption(f"Tools invoked: {' · '.join(tool_labels)} | Model: {data.get('model_used', '—')}")


# ─── Sidebar ─────────────────────────────────────────────────────────────────

def render_sidebar():
    with st.sidebar:
        st.markdown("""
        <div class="brand-header">
          <h1>🚢 CargoSense</h1>
          <p>Shipment Intelligence Agent<br>Pakistan Import Markets</p>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("#### 🎯 Demo Scenarios")
        scenarios = load_demo_scenarios()
        for scenario in scenarios:
            if st.button(scenario["label"], key=f"scenario_{scenario['id']}"):
                st.session_state["pending_query"] = scenario["query"]

        st.markdown("---")
        st.markdown("#### ⚙️ API Settings")
        api_url = st.text_input("Backend URL", value=API_BASE, key="api_url")
        if st.button("🔍 Check API Health"):
            try:
                r = requests.get(f"{api_url}/health", timeout=5)
                if r.status_code == 200:
                    st.success("✅ API is online")
                else:
                    st.warning(f"⚠️ API returned {r.status_code}")
            except Exception:
                st.error("❌ Cannot reach API")

        st.markdown("---")
        st.markdown("#### 📘 How It Works")
        st.markdown("""
        <div style="color:#8b949e;font-size:0.78rem;line-height:1.6;">
        1. You type a shipment query<br>
        2. FastAPI sends it to Gemini 2.0<br>
        3. Gemini calls 3 tools:<br>
           &nbsp;&nbsp;• get_news(location)<br>
           &nbsp;&nbsp;• calculate_duty(hs, value)<br>
           &nbsp;&nbsp;• get_route_risk(from, to)<br>
        4. Structured response shown here
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")
        if st.button("🗑️ Clear Chat History"):
            st.session_state["messages"] = []
            st.session_state["last_response"] = None
            st.rerun()


# ─── Main App ─────────────────────────────────────────────────────────────────

def main():
    # ── Session state init ────────────────────────────────────────────────────
    if "messages" not in st.session_state:
        st.session_state["messages"] = []
    if "last_response" not in st.session_state:
        st.session_state["last_response"] = None
    if "pending_query" not in st.session_state:
        st.session_state["pending_query"] = ""

    render_sidebar()

    # ── Page header ───────────────────────────────────────────────────────────
    hdr_col, badge_col = st.columns([3, 1])
    with hdr_col:
        st.markdown("## 🚢 CargoSense — Shipment Intelligence")
        st.markdown(
            '<span style="color:#8b949e;font-size:0.85rem;">'
            'AI-powered risk analysis for Pakistani importers — '
            'Red Sea, Strait of Hormuz, PKR duties, rerouting intelligence.'
            '</span>',
            unsafe_allow_html=True
        )
    with badge_col:
        if st.session_state["last_response"]:
            lvl = st.session_state["last_response"].get("risk_level", "")
            st.markdown(
                f'<div style="text-align:right;padding-top:1rem;">{risk_badge(lvl)}</div>',
                unsafe_allow_html=True
            )

    st.markdown("---")

    # ── Layout: Left (chat + report) | Right (map) ───────────────────────────
    main_col, map_col = st.columns([1.1, 0.9])

    # ── CHAT PANEL ────────────────────────────────────────────────────────────
    with main_col:
        # Chat history
        if st.session_state["messages"]:
            with st.container():
                for msg in st.session_state["messages"][-8:]:  # show last 8
                    if msg["role"] == "user":
                        st.markdown(
                            f'<div class="chat-user">'
                            f'<div class="chat-label">You</div>{msg["content"]}'
                            f'</div>',
                            unsafe_allow_html=True
                        )
                    else:
                        st.markdown(
                            f'<div class="chat-agent">'
                            f'<div class="chat-label">🚢 CargoSense</div>{msg["content"]}'
                            f'</div>',
                            unsafe_allow_html=True
                        )

        # Input area
        pending = st.session_state.pop("pending_query", "") if "pending_query" in st.session_state else ""
        user_input = st.text_area(
            "Your shipment query",
            value=pending or DEFAULT_QUERY,
            height=100,
            placeholder=DEFAULT_QUERY,
            label_visibility="collapsed",
            key="chat_input",
        )

        send_col, clear_col = st.columns([2, 1])
        with send_col:
            send_clicked = st.button("🔍 Analyse Shipment", type="primary", use_container_width=True)
        with clear_col:
            if st.button("✕ Clear", use_container_width=True):
                st.session_state["messages"] = []
                st.session_state["last_response"] = None
                st.rerun()

        # Process query
        if send_clicked and user_input.strip():
            st.session_state["messages"].append({"role": "user", "content": user_input})

            with st.spinner("🔍 Agent is querying news, duties, and route risk..."):
                start = time.time()
                response = call_api(user_input)
                elapsed = time.time() - start

            if response:
                agent_reply = response.get("agent_response", "No response from agent.")
                st.session_state["messages"].append({"role": "assistant", "content": agent_reply})
                st.session_state["last_response"] = response
                st.caption(f"⏱ Analysis completed in {elapsed:.1f}s")
                st.rerun()

        # ── Report card (shown below chat) ───────────────────────────────────
        if st.session_state["last_response"]:
            st.markdown("<br>", unsafe_allow_html=True)
            render_report_card(st.session_state["last_response"])

        # ── News summary ──────────────────────────────────────────────────────
        if st.session_state["last_response"]:
            news_text = st.session_state["last_response"].get("news_summary", "")
            if news_text:
                with st.expander("📰 News Intelligence Summary"):
                    st.markdown(
                        f'<div style="color:#cdd9e5;font-size:0.85rem;line-height:1.7;">{news_text}</div>',
                        unsafe_allow_html=True
                    )

    # ── MAP PANEL ─────────────────────────────────────────────────────────────
    with map_col:
        st.markdown('<div class="section-title">🗺️ TRADE ROUTE RISK MAP</div>', unsafe_allow_html=True)

        route_data = st.session_state["last_response"].get("route_info") if st.session_state["last_response"] else None
        fmap = build_heatmap(route_data)

        st_folium(
            fmap,
            width=None,
            height=520,
            returned_objects=[],
            key="risk_map",
        )

        # Map legend
        st.markdown("""
        <div style="font-size:0.75rem;color:#6e7681;margin-top:0.5rem;text-align:center;">
          🔴 High Risk &nbsp;|&nbsp; 🟡 Medium Risk &nbsp;|&nbsp; 🟢 Low Risk Route<br>
          Shaded zones = Active maritime conflict areas
        </div>
        """, unsafe_allow_html=True)

        # Quick stats
        if not st.session_state["last_response"]:
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown("""
            <div class="report-section">
              <h4>📡 LIVE THREAT OVERVIEW</h4>
              <p style="color:#8b949e;font-size:0.82rem;">
              Send a query to see real-time risk analysis.<br><br>
              <b style="color:#f85149;">🔴 Hormuz Strait</b> — Iranian naval exercises<br>
              <b style="color:#f85149;">🔴 Gulf of Aden</b> — Houthi drone operations<br>
              <b style="color:#e3b341;">🟡 Suez Canal</b> — Diversion surcharges<br>
              <b style="color:#3fb950;">🟢 Colombo Route</b> — Recommended alternative<br>
              </p>
            </div>
            """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()