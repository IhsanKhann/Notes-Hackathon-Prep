"""
CargoSense — Route Risk Tool
Calculates risk scores for maritime trade routes to Pakistan.
Returns a score (0–10), colour (Red/Amber/Green), and alternative route suggestions.
"""

import json
from pathlib import Path

_DATA_DIR = Path(__file__).parent.parent.parent / "data"
_ROUTE_FILE = _DATA_DIR / "route_risk.json"


def _load_route_data() -> dict:
    try:
        with open(_ROUTE_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        return {"routes": {}, "ports": {}}


ROUTE_DATA = _load_route_data()


def _normalise(text: str) -> str:
    return text.lower().strip()


def _match_route(origin: str, destination: str) -> dict | None:
    """Fuzzy-match origin/destination to a known route key."""
    o = _normalise(origin)
    d = _normalise(destination)

    # Direct key lookup
    for key, route in ROUTE_DATA["routes"].items():
        waypoints_lower = [w.lower() for w in route["waypoints"]]
        if (any(o in wp for wp in waypoints_lower)
                and any(d in wp for wp in waypoints_lower)):
            return {**route, "route_key": key}

    # Fallback: origin match
    for key, route in ROUTE_DATA["routes"].items():
        waypoints_lower = [w.lower() for w in route["waypoints"]]
        if any(o in wp for wp in waypoints_lower):
            return {**route, "route_key": key}

    return None


def get_route_risk(origin: str, destination: str) -> dict:
    """
    Returns a risk assessment for the maritime route from origin to destination.

    Args:
        origin:      Port or city of origin (e.g., 'Shenzhen', 'Dubai', 'Rotterdam')
        destination: Port or city of destination (e.g., 'Karachi')

    Returns:
        dict with risk_score (0–10), risk_level (HIGH/MEDIUM/LOW),
        color (red/orange/green), recommended_route, and alternatives.
    """
    matched = _match_route(origin, destination)

    if matched is None:
        # Generic response for unknown routes
        return {
            "origin": origin,
            "destination": destination,
            "risk_score": 4.0,
            "risk_level": "MEDIUM",
            "color": "orange",
            "recommended_route": f"{origin} → Colombo → {destination}",
            "transit_days": 20,
            "cost_multiplier": 1.15,
            "insurance_surcharge_pct": 0.10,
            "active_threats": ["Unable to find specific route data; using conservative estimate"],
            "alternative_routes": [
                f"{origin} → Colombo → {destination} (safest option)",
                f"{origin} → Jebel Ali → {destination} (faster if goods already in Gulf)",
            ],
            "all_routes": list(ROUTE_DATA.get("routes", {}).values()),
            "ports": ROUTE_DATA.get("ports", {}),
            "note": "Route not in database — generic risk applied.",
        }

    # Build alternatives (all routes except the matched one)
    all_routes = ROUTE_DATA["routes"]
    alternatives = [
        r["label"]
        for k, r in all_routes.items()
        if k != matched["route_key"] and r["risk_score"] < matched["risk_score"]
    ]
    alternatives.sort(key=lambda label: next(
        r["risk_score"] for r in all_routes.values() if r["label"] == label
    ))

    # Risk colour mapping
    score = matched["base_risk_score"]
    if score >= 7.0:
        risk_level = "HIGH"
        color = "red"
    elif score >= 4.0:
        risk_level = "MEDIUM"
        color = "orange"
    else:
        risk_level = "LOW"
        color = "green"

    # Recommended route (lowest risk going to same destination)
    best_key = min(all_routes, key=lambda k: all_routes[k]["risk_score"])
    best_route = all_routes[best_key]

    return {
        "origin": origin,
        "destination": destination,
        "matched_route": matched["label"],
        "risk_score": score,
        "risk_level": risk_level,
        "color": color,
        "recommended_route": best_route["label"],
        "transit_days": matched["transit_days"],
        "cost_multiplier": matched["cost_multiplier"],
        "insurance_surcharge_pct": matched["insurance_surcharge_pct"],
        "active_threats": matched.get("active_threats", []),
        "alternative_routes": alternatives[:3],
        "best_alternative": {
            "label": best_route["label"],
            "risk_score": best_route["risk_score"],
            "transit_days": best_route["transit_days"],
            "insurance_surcharge_pct": best_route["insurance_surcharge_pct"],
        },
        "all_routes": list(all_routes.values()),
        "ports": ROUTE_DATA.get("ports", {}),
    }