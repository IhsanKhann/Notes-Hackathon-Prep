"""
CargoSense — FastAPI Backend
Exposes the /chat endpoint that the Streamlit frontend calls.

Run locally:
    uvicorn app.main:app --reload --port 8000

Production (Docker / Cloud Run):
    uvicorn app.main:app --host 0.0.0.0 --port 8080
"""

import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.schemas import ChatRequest, ChatResponse, HealthResponse
from app.agent import run_agent

# ─── Logging ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("cargosense")


# ─── App Lifecycle ────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚢 CargoSense API starting up...")
    yield
    logger.info("CargoSense API shut down.")


# ─── FastAPI App ──────────────────────────────────────────────────────────────

app = FastAPI(
    title="CargoSense — Shipment Intelligence API",
    description=(
        "AI-powered risk intelligence for Pakistani importers. "
        "Uses Gemini 2.0 Flash with function calling to analyse maritime routes, "
        "calculate customs duties, and summarise geopolitical news."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ─── CORS (allow Streamlit on any port during development) ───────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Middleware: Request Timing ───────────────────────────────────────────────

@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration = round(time.time() - start, 3)
    response.headers["X-Process-Time"] = str(duration)
    logger.info(f"{request.method} {request.url.path} → {response.status_code} ({duration}s)")
    return response


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.get("/", response_model=HealthResponse, tags=["Health"])
async def root():
    """Health check endpoint."""
    return HealthResponse()


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health():
    """Detailed health check."""
    return HealthResponse()


@app.post(
    "/chat",
    response_model=ChatResponse,
    tags=["Agent"],
    summary="Query the CargoSense Shipment Intelligence Agent",
    response_description="Structured risk assessment with duty breakdown and route recommendation",
)
async def chat(request: ChatRequest) -> ChatResponse:
    """
    Send a natural language shipment query to the CargoSense agent.

    The agent uses Gemini 2.0 Flash with function calling to:
    1. Retrieve relevant maritime/trade news (`get_news`)
    2. Calculate Pakistan import duties in PKR (`calculate_duty`)
    3. Score route risk and recommend alternatives (`get_route_risk`)

    **Example query:**
    > Electronics from Shenzhen via Hormuz to Karachi — what is my risk today?

    **Returns:** Structured JSON with `risk_level`, `risk_score`, `news_summary`,
    `duty_breakdown`, `route_recommendation`, and the full `agent_response`.
    """
    if not request.message.strip():
        raise HTTPException(status_code=422, detail="Message cannot be empty.")

    if len(request.message) > 2000:
        raise HTTPException(status_code=422, detail="Message too long (max 2000 characters).")

    try:
        logger.info(f"Incoming query: {request.message[:100]}...")
        result = run_agent(request.message)
        logger.info(f"Agent response: risk={result.risk_level} score={result.risk_score} tools={result.tools_used}")
        return result

    except Exception as exc:
        logger.exception(f"Agent error: {exc}")
        raise HTTPException(
            status_code=500,
            detail=f"Agent processing failed: {str(exc)[:200]}",
        )


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception(f"Unhandled exception on {request.url}: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error. Please try again."},
    )