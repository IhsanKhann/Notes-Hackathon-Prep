"""
CargoSense — Duty Calculation Tool
Calculates Pakistan import duties in PKR using FBR (Federal Board of Revenue) rates.
In production: looks up live PKR/USD rate via ExchangeRate-API.
In demo mode: uses a realistic static rate.
"""

import json
import os
from pathlib import Path

# ─── Load HS Code Data ───────────────────────────────────────────────────────

_DATA_DIR = Path(__file__).parent.parent.parent / "data"
_HS_CODES_FILE = _DATA_DIR / "hs_codes.json"

def _load_hs_codes() -> dict:
    try:
        with open(_HS_CODES_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

HS_CODES = _load_hs_codes()

# Live rate in production — fetch from ExchangeRate-API
DEFAULT_USD_TO_PKR = float(os.getenv("USD_TO_PKR_RATE", "278.5"))

# Generic fallback for unknown HS codes
GENERIC_RATES = {
    "customs_duty": 0.20,
    "additional_customs_duty": 0.02,
    "sales_tax": 0.17,
    "withholding_tax": 0.06,
    "regulatory_duty": 0.0,
    "notes": "Generic rates applied — verify with FBR for your exact HS code.",
}


def calculate_duty(hs_code: str, value: float, currency: str = "USD") -> dict:
    """
    Calculates Pakistan import duty breakdown for a given HS code and shipment value.

    Args:
        hs_code:  6-digit HS code (e.g., "8471" for computers)
        value:    Declared customs value
        currency: "USD" (default) or "PKR"

    Returns:
        dict matching the DutyBreakdown Pydantic schema
    """
    hs_code = str(hs_code).strip().replace(".", "")[:6]  # normalise

    # Resolve PKR value
    usd_to_pkr = DEFAULT_USD_TO_PKR
    if currency.upper() == "PKR":
        value_pkr = float(value)
        value_usd = value_pkr / usd_to_pkr
    else:
        value_usd = float(value)
        value_pkr = value_usd * usd_to_pkr

    # Look up rates
    rates = HS_CODES.get(hs_code, None)
    if rates is None:
        # Try 4-digit prefix
        rates = HS_CODES.get(hs_code[:4], None)
    if rates is None:
        rates = GENERIC_RATES
        description = "Unknown commodity (generic rates applied)"
    else:
        description = rates.get("description", "")

    # ─── Calculate each duty component ───────────────────────────────────────
    # Pakistani duty structure (cascading on the assessable value):
    # 1. Customs Duty  → on CIF value
    # 2. Additional Customs Duty (ACD) → on CIF value
    # 3. Regulatory Duty (RD) → on CIF value
    # 4. Sales Tax (GST) → on (CIF + Customs Duty + ACD + RD)
    # 5. Withholding Tax (WHT) → on (CIF + all duties above + ST)

    cd_pct  = rates.get("customs_duty", 0.20)
    acd_pct = rates.get("additional_customs_duty", 0.02)
    rd_pct  = rates.get("regulatory_duty", 0.0)
    st_pct  = rates.get("sales_tax", 0.17)
    wht_pct = rates.get("withholding_tax", 0.06)

    cd_pkr  = value_pkr * cd_pct
    acd_pkr = value_pkr * acd_pct
    rd_pkr  = value_pkr * rd_pct

    # Sales tax base = CIF + CD + ACD + RD
    st_base  = value_pkr + cd_pkr + acd_pkr + rd_pkr
    st_pkr   = st_base * st_pct

    # WHT base = CIF + CD + ACD + RD + ST
    wht_base = st_base + st_pkr
    wht_pkr  = wht_base * wht_pct

    total_duty_pkr = cd_pkr + acd_pkr + rd_pkr + st_pkr + wht_pkr
    effective_rate = total_duty_pkr / value_pkr if value_pkr > 0 else 0

    return {
        "hs_code": hs_code,
        "description": description,
        "value_usd": round(value_usd, 2),
        "value_pkr": round(value_pkr, 2),
        "usd_to_pkr_rate": usd_to_pkr,

        # Rates
        "customs_duty_pct": cd_pct,
        "additional_customs_duty_pct": acd_pct,
        "regulatory_duty_pct": rd_pct,
        "sales_tax_pct": st_pct,
        "withholding_tax_pct": wht_pct,

        # PKR amounts
        "customs_duty_pkr": round(cd_pkr, 2),
        "additional_customs_duty_pkr": round(acd_pkr, 2),
        "regulatory_duty_pkr": round(rd_pkr, 2),
        "sales_tax_pkr": round(st_pkr, 2),
        "withholding_tax_pkr": round(wht_pkr, 2),

        # Totals
        "total_duty_pkr": round(total_duty_pkr, 2),
        "effective_duty_rate": round(effective_rate * 100, 2),  # as %
        "total_landed_cost_pkr": round(value_pkr + total_duty_pkr, 2),

        "notes": rates.get("notes", ""),
        "disclaimer": (
            "Indicative calculation only. Final duty determined by Pakistan Customs "
            "at port of entry. Rates based on FBR schedules — verify before booking."
        ),
    }