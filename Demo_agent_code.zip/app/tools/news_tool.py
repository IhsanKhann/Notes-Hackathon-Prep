"""
CargoSense — News Tool
In production: calls NewsAPI.org with NEWS_API_KEY.
In demo/mock mode: returns curated realistic news for Pakistani importers.
"""

import os
import random
from datetime import datetime, timedelta


# ─── Mock News Database ──────────────────────────────────────────────────────

MOCK_NEWS = {
    "hormuz": [
        {
            "headline": "Iranian Navy Conducts Live-Fire Exercise Near Strait of Hormuz",
            "source": "Reuters",
            "severity": "HIGH",
            "summary": (
                "Iranian naval forces completed a two-day live-fire exercise 18 nautical miles "
                "from the commercial shipping lane in the Strait of Hormuz. Lloyd's of London "
                "has issued a Category 3 war-risk advisory. Four container vessels rerouted to "
                "Colombo transshipment hub, adding average 6-day delays to Pakistan-bound cargo."
            ),
            "impact": "Insurance premiums up 35% for vessels transiting Hormuz this week.",
        },
        {
            "headline": "Houthi Forces Claim Attack on Cargo Vessel in Gulf of Aden",
            "source": "AP News",
            "severity": "HIGH",
            "summary": (
                "Houthi forces claimed responsibility for a drone strike on a Liberian-flagged "
                "cargo vessel 40 miles off the Yemeni coast. The vessel sustained minor damage "
                "and rerouted to Djibouti. UKMTO issued a warning to all commercial vessels "
                "in the southern Red Sea corridor."
            ),
            "impact": "Shipping lines adding war-risk surcharge of $500–$800 per TEU.",
        },
        {
            "headline": "UKMTO Issues Warning: Unmanned Aerial Vehicle Activity Near Hormuz",
            "source": "UKMTO Advisory",
            "severity": "MEDIUM",
            "summary": (
                "The United Kingdom Maritime Trade Operations (UKMTO) has issued a general "
                "warning regarding unmanned aerial vehicle (UAV) activity reported within "
                "50 nautical miles of the Strait of Hormuz. Commercial vessels advised to "
                "maintain heightened watch and report suspicious activity."
            ),
            "impact": "Precautionary measure; no vessels struck. Recommend increased vigilance.",
        },
    ],
    "red_sea": [
        {
            "headline": "Major Shipping Lines Suspend Red Sea Transits Indefinitely",
            "source": "Lloyd's List",
            "severity": "HIGH",
            "summary": (
                "Maersk, MSC, and CMA CGM have extended their Red Sea suspension through Q2 2026. "
                "Vessels are diverting via Cape of Good Hope, adding 10–14 days and approximately "
                "$1,200 per TEU in fuel costs. Karachi importers should expect 3–4 week additional "
                "transit times on Europe-origin shipments."
            ),
            "impact": "Significant freight rate increase. Budget $400–$600/TEU extra for Europe imports.",
        },
    ],
    "karachi": [
        {
            "headline": "Karachi Port Trust Announces 72-Hour Labour Strike — Customs Cleared",
            "source": "Dawn Business",
            "severity": "MEDIUM",
            "summary": (
                "KPT dock workers' union called a 72-hour work stoppage starting Monday over wage "
                "disputes. Port operations at Berths 1–14 will be affected. QICT terminal (Berths 15–20) "
                "is operating normally. Pakistan Customs has confirmed continued clearance operations "
                "during the strike."
            ),
            "impact": "2–3 day delay for bulk cargo. Container terminal largely unaffected.",
        },
        {
            "headline": "SBP Tightens Import LC Requirements — Electronics Category Affected",
            "source": "The News International",
            "severity": "MEDIUM",
            "summary": (
                "State Bank of Pakistan has tightened LC issuance requirements for non-essential "
                "imports including consumer electronics. Importers must now provide 100% cash margin "
                "for LCs above $50,000 USD. This follows foreign exchange reserve pressure amid "
                "PKR depreciation concerns."
            ),
            "impact": "Increased working capital requirement for electronics importers.",
        },
    ],
    "shenzhen": [
        {
            "headline": "Yantian Port Congestion Easing — Delays Down to 4 Days",
            "source": "Alphaliner",
            "severity": "LOW",
            "summary": (
                "Congestion at Yantian International Container Terminal (Shenzhen) has improved "
                "significantly after two weeks of high volumes. Average vessel waiting time is now "
                "4 days, down from 11 days last month. Export capacity is returning to normal for "
                "Q2 2026 bookings."
            ),
            "impact": "Good news: book your China-Pakistan shipments now while capacity is available.",
        },
    ],
    "general": [
        {
            "headline": "PKR Depreciates 2.3% Against USD — Importer Alert",
            "source": "State Bank of Pakistan",
            "severity": "MEDIUM",
            "summary": (
                "The Pakistani Rupee has weakened by 2.3% against the US Dollar in the past two weeks, "
                "touching PKR 283/USD in interbank trading. This increases the PKR cost of all USD-denominated "
                "imports. The SBP has intervened twice but analysts expect continued pressure until "
                "the IMF tranche is released."
            ),
            "impact": "Add 2–3% buffer to all USD import cost calculations.",
        },
    ],
}


def get_news(location: str) -> dict:
    """
    Retrieves recent maritime / trade news relevant to the given location.

    Args:
        location: Port, strait, or region name (e.g., 'Hormuz', 'Karachi', 'Red Sea')

    Returns:
        dict with keys: location, articles (list), severity, summary
    """
    location_lower = location.lower()

    # Match location to mock news category
    if any(kw in location_lower for kw in ["hormuz", "gulf", "iran", "persian"]):
        articles = MOCK_NEWS["hormuz"]
    elif any(kw in location_lower for kw in ["red sea", "houthi", "aden", "yemen"]):
        articles = MOCK_NEWS["red_sea"]
    elif any(kw in location_lower for kw in ["karachi", "pakistan", "kpt"]):
        articles = MOCK_NEWS["karachi"]
    elif any(kw in location_lower for kw in ["shenzhen", "china", "yantian", "guangdong"]):
        articles = MOCK_NEWS["shenzhen"]
    else:
        articles = MOCK_NEWS["general"]

    # Always add a general article for context
    combined = articles + [random.choice(MOCK_NEWS["general"])]

    # Compute overall severity
    severities = [a["severity"] for a in combined]
    if "HIGH" in severities:
        overall_severity = "HIGH"
    elif "MEDIUM" in severities:
        overall_severity = "MEDIUM"
    else:
        overall_severity = "LOW"

    # Build plain summary for agent consumption
    top = combined[0]
    summary = f"[{top['source']}] {top['headline']}: {top['summary'][:200]}..."

    return {
        "location": location,
        "articles_found": len(combined),
        "severity": overall_severity,
        "top_headline": top["headline"],
        "summary": summary,
        "impact": top["impact"],
        "articles": [
            {
                "headline": a["headline"],
                "source": a["source"],
                "severity": a["severity"],
                "summary": a["summary"],
                "impact": a["impact"],
            }
            for a in combined[:3]
        ],
        "data_timestamp": (datetime.utcnow() - timedelta(hours=random.randint(1, 6))).isoformat() + "Z",
        "note": "Mock data — connect NEWS_API_KEY for live feed",
    }