"""
CargoSense — Gemini Agent with Function Calling
Uses google-generativeai SDK (Gemini 2.0 Flash) with three tools:
  • get_news(location)
  • calculate_duty(hs_code, value)
  • get_route_risk(origin, destination)

To switch to Vertex AI SDK: replace the genai.configure() block with
vertexai.init(project=PROJECT_ID, location=LOCATION) and
use vertexai.generative_models.GenerativeModel instead.
"""

import os
import json
import re
import logging
from typing import Any

import google.generativeai as genai

from app.tools.news_tool import get_news
from app.tools.duty_tool import calculate_duty
from app.tools.route_tool import get_route_risk
from app.schemas import ChatResponse, DutyBreakdown, RouteInfo

logger = logging.getLogger(__name__)

# ─── Configure Gemini ────────────────────────────────────────────────────────

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# ─── Tool Declarations (Gemini Function Calling Schema) ──────────────────────

_TOOLS = [
    genai.protos.Tool(
        function_declarations=[
            genai.protos.FunctionDeclaration(
                name="get_news",
                description=(
                    "Retrieves the latest maritime and trade news for a specific port, "
                    "strait, or region relevant to Pakistan imports. Use this whenever "
                    "the user asks about risk, safety, or current events on a route."
                ),
                parameters=genai.protos.Schema(
                    type=genai.protos.Type.OBJECT,
                    properties={
                        "location": genai.protos.Schema(
                            type=genai.protos.Type.STRING,
                            description=(
                                "The port, strait, or region to get news for. "
                                "Examples: 'Hormuz', 'Red Sea', 'Karachi', 'Shenzhen'."
                            ),
                        )
                    },
                    required=["location"],
                ),
            ),
            genai.protos.FunctionDeclaration(
                name="calculate_duty",
                description=(
                    "Calculates Pakistan import duty and tax breakdown in PKR for a "
                    "given HS code and shipment value. Use this when the user mentions "
                    "an HS code, a product category, or asks about costs, duties, or taxes."
                ),
                parameters=genai.protos.Schema(
                    type=genai.protos.Type.OBJECT,
                    properties={
                        "hs_code": genai.protos.Schema(
                            type=genai.protos.Type.STRING,
                            description=(
                                "The 4–6 digit HS (Harmonized System) code. "
                                "Examples: '8471' for computers, '8517' for phones, '8703' for cars."
                            ),
                        ),
                        "value": genai.protos.Schema(
                            type=genai.protos.Type.NUMBER,
                            description="The declared customs value of the shipment (numeric, no commas).",
                        ),
                        "currency": genai.protos.Schema(
                            type=genai.protos.Type.STRING,
                            description="Currency of the value: 'USD' (default) or 'PKR'.",
                        ),
                    },
                    required=["hs_code", "value"],
                ),
            ),
            genai.protos.FunctionDeclaration(
                name="get_route_risk",
                description=(
                    "Returns a risk score (0–10) and colour (Red/Amber/Green) for a maritime "
                    "route, along with alternative route recommendations. Use this whenever "
                    "the user mentions a shipping route, origin port, or asks about rerouting."
                ),
                parameters=genai.protos.Schema(
                    type=genai.protos.Type.OBJECT,
                    properties={
                        "origin": genai.protos.Schema(
                            type=genai.protos.Type.STRING,
                            description="Port or city of origin (e.g., 'Shenzhen', 'Dubai', 'Rotterdam').",
                        ),
                        "destination": genai.protos.Schema(
                            type=genai.protos.Type.STRING,
                            description="Port or city of destination (e.g., 'Karachi').",
                        ),
                    },
                    required=["origin", "destination"],
                ),
            ),
        ]
    )
]

# ─── System Prompt ───────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are CargoSense — a Shipment Intelligence Agent specialising in Pakistan import logistics.

Your users are Pakistani importers and freight forwarders who face:
- Maritime security risks (Red Sea, Strait of Hormuz, Houthi attacks)
- Currency volatility (PKR/USD fluctuations)
- Complex customs duties (FBR rates, multiple tax layers)
- Port delays (Karachi Port Trust congestion)

You have three tools available:
1. get_news(location) — get maritime/trade news for a port or region
2. calculate_duty(hs_code, value) — calculate Pakistan import duties in PKR
3. get_route_risk(origin, destination) — get risk score and route recommendations

ALWAYS use the tools before answering. Do not guess at news or duty rates.

Response format:
- Be direct and actionable — Pakistani importers want decisions, not essays
- Lead with the risk level: HIGH 🔴 / MEDIUM 🟡 / LOW 🟢
- Give exact numbers (risk score, PKR amounts, transit days)
- Always end with a concrete recommendation
- Keep the full response under 300 words

Language: Professional English. You may use occasional Urdu terms (like "bhai", "sahib") only if it fits naturally — do not force it.
"""

# ─── Tool Dispatcher ─────────────────────────────────────────────────────────
def _dispatch_tool(name: str, args: dict) -> Any:
    """Routes a Gemini function call to the correct Python tool."""
    if name == "get_news":
        return get_news(location=args.get("location", "general"))
    elif name == "calculate_duty":
        return calculate_duty(
            hs_code=str(args.get("hs_code", "8471")),
            value=float(args.get("value", 0)),
            currency=args.get("currency", "USD"),
        )
    elif name == "get_route_risk":
        return get_route_risk(
            origin=args.get("origin", "Shenzhen"),
            destination=args.get("destination", "Karachi"),
        )
    else:
        return {"error": f"Unknown tool: {name}"}


# ─── Response Parser ─────────────────────────────────────────────────────────
def _extract_risk(agent_text: str, route_data: dict | None, news_data: dict | None) -> tuple[str, float]:
    """Derives risk_level and risk_score from tool outputs and agent text."""
    # Priority: route risk score
    if route_data and "risk_score" in route_data:
        score = float(route_data["risk_score"])
        if score >= 7.0:
            return "HIGH", score
        elif score >= 4.0:
            return "MEDIUM", score
        else:
            return "LOW", score

    # Fallback: news severity
    if news_data and "severity" in news_data:
        sev = news_data["severity"]
        if sev == "HIGH":
            return "HIGH", 7.5
        elif sev == "MEDIUM":
            return "MEDIUM", 5.0
        else:
            return "LOW", 2.0

    # Last resort: parse agent text
    text_lower = agent_text.lower()
    if "high" in text_lower or "🔴" in agent_text:
        return "HIGH", 7.0
    elif "medium" in text_lower or "🟡" in agent_text:
        return "MEDIUM", 5.0
    return "LOW", 2.5


def _build_duty_breakdown(duty_data: dict | None) -> DutyBreakdown | None:
    if not duty_data:
        return None
    return DutyBreakdown(
        hs_code=duty_data.get("hs_code"),
        value_usd=duty_data.get("value_usd"),
        value_pkr=duty_data.get("value_pkr"),
        customs_duty_pct=duty_data.get("customs_duty_pct", 0),
        customs_duty_pkr=duty_data.get("customs_duty_pkr", 0),
        sales_tax_pct=duty_data.get("sales_tax_pct", 0),
        sales_tax_pkr=duty_data.get("sales_tax_pkr", 0),
        withholding_tax_pct=duty_data.get("withholding_tax_pct", 0),
        withholding_tax_pkr=duty_data.get("withholding_tax_pkr", 0),
        additional_customs_duty_pct=duty_data.get("additional_customs_duty_pct", 0),
        additional_customs_duty_pkr=duty_data.get("additional_customs_duty_pkr", 0),
        regulatory_duty_pct=duty_data.get("regulatory_duty_pct", 0),
        regulatory_duty_pkr=duty_data.get("regulatory_duty_pkr", 0),
        total_duty_pkr=duty_data.get("total_duty_pkr", 0),
        effective_duty_rate=duty_data.get("effective_duty_rate", 0),
        usd_to_pkr_rate=duty_data.get("usd_to_pkr_rate", 278.5),
        notes=duty_data.get("notes"),
    )


def _build_route_info(route_data: dict | None) -> RouteInfo | None:
    if not route_data:
        return None
    color_map = {"red": "RED", "orange": "AMBER", "green": "GREEN"}
    return RouteInfo(
        origin=route_data.get("origin"),
        destination=route_data.get("destination"),
        recommended_route=route_data.get("recommended_route"),
        risk_color=color_map.get(route_data.get("color", "green"), "GREEN"),
        transit_days=route_data.get("transit_days"),
        cost_multiplier=route_data.get("cost_multiplier"),
        insurance_surcharge_pct=route_data.get("insurance_surcharge_pct"),
        active_threats=route_data.get("active_threats", []),
        alternative_routes=route_data.get("alternative_routes", []),
    )


# ─── Main Agent Function ─────────────────────────────────────────────────────
def run_agent(user_message: str) -> ChatResponse:
    """
    Runs the CargoSense Gemini agent with function calling.
    Handles multi-turn tool use loop until the model produces a final text response.
    """
    if not GEMINI_API_KEY:
        # ── DEMO MODE (no API key) ──────────────────────────────────────────
        logger.warning("GEMINI_API_KEY not set — running in demo mode with mock response.")
        return _demo_response(user_message)

    model = genai.GenerativeModel(
        model_name="gemini-2.0-flash",
        system_instruction=SYSTEM_PROMPT,
        tools=_TOOLS,
    )

    # Start conversation
    messages = [{"role": "user", "parts": [user_message]}]
    tools_used: list[str] = []
    news_data: dict | None = None
    duty_data: dict | None = None
    route_data: dict | None = None

    # Agentic loop (max 6 turns to prevent runaway)
    for _ in range(6):
        response = model.generate_content(messages) # text generation using the API..
        candidate = response.candidates[0]
        parts = candidate.content.parts

        # Check for function calls
        tool_calls = [p for p in parts if hasattr(p, "function_call") and p.function_call.name]
        if not tool_calls:
            # Model produced a final text response
            final_text = "".join(p.text for p in parts if hasattr(p, "text") and p.text)
            break

        # Execute all tool calls in this turn
        tool_results = []
        for part in tool_calls:
            fc = part.function_call
            args = dict(fc.args)
            logger.info(f"Tool call: {fc.name}({args})")
            result = _dispatch_tool(fc.name, args)
            tools_used.append(fc.name)

            # Capture for structured response
            if fc.name == "get_news":
                news_data = result
            elif fc.name == "calculate_duty":
                duty_data = result
            elif fc.name == "get_route_risk":
                route_data = result

            tool_results.append(
                genai.protos.Part(
                    function_response=genai.protos.FunctionResponse(
                        name=fc.name,
                        response={"result": json.dumps(result, default=str)},
                    )
                )
            )

        # Append model turn + tool results to conversation
        messages.append({"role": "model", "parts": parts})
        messages.append({"role": "user", "parts": tool_results})

    else:
        final_text = "I've gathered the intelligence but hit my processing limit. Please try a more specific query."

    # ── Build structured response ─────────────────────────────────────────
    risk_level, risk_score = _extract_risk(final_text, route_data, news_data)

    news_summary = (
        news_data.get("summary", "No recent news retrieved.")
        if news_data
        else "No specific news data retrieved."
    )

    route_rec = (
        route_data.get("recommended_route", "")
        if route_data
        else "Consult a freight forwarder for route advice."
    )
    if route_data and route_data.get("alternative_routes"):
        route_rec += f". Alternatives: {', '.join(route_data['alternative_routes'][:2])}"

    return ChatResponse(
        risk_level=risk_level,
        risk_score=risk_score,
        news_summary=news_summary,
        duty_breakdown=_build_duty_breakdown(duty_data),
        route_recommendation=route_rec,
        route_info=_build_route_info(route_data),
        agent_response=final_text,
        tools_used=list(set(tools_used)),
        model_used="gemini-2.0-flash",
    )


# ─── Demo Mode (no API key) ──────────────────────────────────────────────────
def _demo_response(user_message: str) -> ChatResponse:
    """Returns a realistic mock response when no Gemini API key is configured."""
    msg_lower = user_message.lower()

    # Determine which tools would have been called
    tools_used = []
    news_data = None
    duty_data = None
    route_data = None

    if any(kw in msg_lower for kw in ["hormuz", "shenzhen", "route", "risk", "karachi"]):
        origin = "Shenzhen" if "shenzhen" in msg_lower else "Dubai"
        route_data = get_route_risk(origin, "Karachi")
        news_data = get_news("Hormuz" if "hormuz" in msg_lower else "Karachi")
        tools_used.extend(["get_route_risk", "get_news"])

    if any(kw in msg_lower for kw in ["duty", "hs", "tax", "cost", "electronic", "phone", "car", "vehicle"]):
        hs = "8471"
        if "phone" in msg_lower or "mobile" in msg_lower:
            hs = "8517"
        elif "car" in msg_lower or "vehicle" in msg_lower:
            hs = "8703"
        duty_data = calculate_duty(hs, 50000, "USD")
        tools_used.append("calculate_duty")

    # Defaults
    if not route_data:
        route_data = get_route_risk("Shenzhen", "Karachi")
        news_data = get_news("Hormuz")
        tools_used.extend(["get_route_risk", "get_news"])

    risk_level, risk_score = _extract_risk("", route_data, news_data)

    agent_text = (
        f"🔴 **RISK LEVEL: {risk_level}** ({risk_score}/10)\n\n"
        f"**Route Analysis:** The Shenzhen → Hormuz → Karachi route is currently scoring "
        f"{risk_score}/10 risk. {route_data.get('active_threats', ['Houthi drone activity'])[0]} "
        f"is the primary threat. Insurance surcharge is {route_data.get('insurance_surcharge_pct', 0.35)*100:.0f}%.\n\n"
        f"**News:** {news_data.get('top_headline', 'Heightened maritime risk in Gulf region.')}\n\n"
        f"**Recommendation:** {route_data.get('recommended_route', 'Reroute via Colombo')} "
        f"— risk score {route_data.get('best_alternative', {}).get('risk_score', 2.1)}/10, "
        f"saves ~30% on insurance.\n\n"
        f"*(Demo mode — add GEMINI_API_KEY for live intelligence)*"
    )

    return ChatResponse(
        risk_level=risk_level,
        risk_score=risk_score,
        news_summary=news_data.get("summary", "Elevated maritime risk in the region."),
        duty_breakdown=_build_duty_breakdown(duty_data),
        route_recommendation=route_data.get("recommended_route", "Reroute via Colombo."),
        route_info=_build_route_info(route_data),
        agent_response=agent_text,
        tools_used=list(set(tools_used)),
        model_used="demo-mode",
    )